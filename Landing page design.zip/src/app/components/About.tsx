const roles = [
  {
    title: "Head / Director of Brand",
    desc: "Brand systems, positioning, CX, content, ecommerce growth.",
  },
  {
    title: "Chief of Staff / BizOps",
    desc: "Operating cadence, prioritization, cross-functional execution.",
  },
  {
    title: "Director of AI Innovation",
    desc: "Practical AI adoption, internal tooling, automation strategy.",
  },
];

const skills = [
  { label: "AI & Automation", items: "ChatGPT · Claude · Codex · Custom GPT Development · AI Workflow Design" },
  { label: "Commerce & Marketing", items: "Shopify · Klaviyo · ActiveCampaign · Mailchimp · Bronto" },
  { label: "Design & Product", items: "Figma · Adobe CC · Photoshop · Illustrator · InDesign · After Effects" },
  { label: "Analytics & Web", items: "Google Analytics · HTML/CSS · Conversion Optimization · UX Strategy" },
];

export function About() {
  return (
    <section
      id="about"
      style={{ background: "hsl(12, 100%, 46%)", fontFamily: "'gopher', sans-serif" }}
      className="py-28 px-8 md:px-14 border-t border-white/20"
    >
      <div className="max-w-5xl mx-auto">
        <p className="text-white text-xs tracking-widest uppercase opacity-50 mb-4">
          About + Resume
        </p>
        <h2
          className="text-white mb-12"
          style={{ fontSize: "clamp(2rem, 5vw, 4rem)", fontWeight: 900, letterSpacing: "-0.02em", lineHeight: 1.05 }}
        >
          ABOUT + RESUME
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-[1.2fr_1fr] gap-16">
          {/* Left: bio */}
          <div>
            <p
              className="text-white mb-5 leading-relaxed"
              style={{ fontSize: "1rem", fontWeight: 600 }}
            >
              Communicate, don't decorate.
            </p>
            <p className="text-white/80 leading-relaxed mb-5" style={{ fontWeight: 400, fontSize: "0.97rem" }}>
              Business leader with 12+ years of experience building brands, operational systems, digital
              products, and customer experiences across e-commerce, manufacturing, media, and startup
              environments.
            </p>
            <p className="text-white/80 leading-relaxed mb-5" style={{ fontWeight: 400, fontSize: "0.97rem" }}>
              Known for translating complex business challenges into scalable solutions through strategic
              thinking, operational leadership, creative direction, and AI-enabled innovation. Experienced
              in leading cross-functional teams, developing revenue-generating marketing systems, building
              internal business tools, and implementing technology that accelerates growth without
              sacrificing customer experience or brand quality.
            </p>
            <p className="text-white/80 leading-relaxed mb-10" style={{ fontWeight: 400, fontSize: "0.97rem" }}>
              As a founding leader of CustomBoxes.io, helped establish operational infrastructure,
              customer acquisition systems, production workflows, and brand strategy that contributed
              to scaling the company to more than $1M in revenue within its first two years.
            </p>

            <div className="flex flex-wrap gap-3">
              {["Vancouver, WA", "Open to remote & relocation", "pharis.design"].map((item) => (
                <span
                  key={item}
                  className="px-3 py-1.5 border border-white/30 text-white/70 uppercase tracking-wider"
                  style={{ fontSize: "0.7rem" }}
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          {/* Right: roles + education */}
          <div>
            <p className="text-white text-xs tracking-widest uppercase opacity-50 mb-6">
              Best-fit roles
            </p>
            <div className="space-y-0 border-t border-white/20 mb-10">
              {roles.map((role) => (
                <div
                  key={role.title}
                  className="py-5 border-b border-white/20"
                >
                  <div className="text-white mb-1" style={{ fontSize: "0.92rem", fontWeight: 600 }}>
                    {role.title}
                  </div>
                  <div className="text-white/60" style={{ fontSize: "0.84rem", fontWeight: 400 }}>
                    {role.desc}
                  </div>
                </div>
              ))}
            </div>

            {/* Education */}
            <div className="mb-8 py-5 border-t border-b border-white/20">
              <p className="text-white/50 text-xs tracking-widest uppercase mb-3">Education</p>
              <div className="text-white font-semibold" style={{ fontSize: "0.92rem" }}>
                Bachelor of Fine Arts, Graphic Design
              </div>
              <div className="text-white/60" style={{ fontSize: "0.84rem", fontWeight: 400 }}>
                Art Institute of Atlanta · Cum Laude
              </div>
            </div>

            <a
              href="mailto:pharis.amanda@gmail.com"
              className="inline-block px-6 py-3 text-sm font-semibold tracking-wider uppercase transition-all hover:opacity-90"
              style={{ background: "#ffffff", color: "hsl(12, 100%, 46%)" }}
            >
              pharis.amanda@gmail.com
            </a>
          </div>
        </div>

        {/* Skills */}
        <div className="mt-20">
          <p className="text-white/50 text-xs tracking-widest uppercase mb-8">Technology & Platforms</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border-t border-l border-white/20">
            {skills.map((s) => (
              <div key={s.label} className="px-7 py-6 border-b border-r border-white/20">
                <div className="text-white text-xs uppercase tracking-widest mb-2 font-semibold opacity-70">
                  {s.label}
                </div>
                <div className="text-white/60" style={{ fontSize: "0.84rem", fontWeight: 400, lineHeight: 1.6 }}>
                  {s.items}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
