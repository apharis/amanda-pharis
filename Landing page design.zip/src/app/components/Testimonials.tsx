const whatIBuilt = [
  {
    case: "01",
    title: "Revenue Operating System",
    bullets: [
      "Primary KPI hierarchy covering site conversion, email revenue, PDP clarity, Autoship behavior, paid traffic quality, and operational readiness.",
      "Ninety-day control plan focused on two objectives: lock revenue predictability and remove operational ambiguity.",
      "Decision gates for what to start, continue, stop, freeze, or kill so new ideas did not derail execution.",
      "SOP ownership framework for peak coverage, prepress exceptions, barcode repair, AI-ready prepress, and customer service quality thresholds.",
    ],
  },
  {
    case: "02",
    title: "Lifecycle Revenue Engine",
    bullets: [
      "Rebuilt email flows with Autoship messaging, expanded behavioral triggers, and aligned campaigns to flow handoffs.",
      "Segmented by new buyers, repeat buyers, high-volume accounts, and lapsed customers with distinct lifecycle moves for each.",
      "Identified reorder CVR (1.73%) as the structural leak — moved from messaging fix to UX and operational fix.",
    ],
  },
  {
    case: "03",
    title: "AI Internal Ecosystem",
    bullets: [
      "Client Service GPT: answers policy, status, print-rule, and disruption questions in consistent voice.",
      "Email GPT: creates campaigns, tests subject lines, applies segmentation logic.",
      "Production Design GPT: codifies print rules, dieline logic, ink constraints, and upgrade reasoning.",
      "Prepress Pro: supports technical prepress questions, file review, and logo recreation workflows.",
    ],
  },
];

export function Testimonials() {
  return (
    <section
      style={{ background: "#111111", fontFamily: "'gopher', sans-serif" }}
      className="py-28 px-8 md:px-14 border-t border-white/10"
    >
      <div className="max-w-5xl mx-auto">
        <p className="text-white/40 text-xs tracking-widest uppercase mb-4">What I Built</p>
        <h2
          className="text-white mb-14"
          style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 900, letterSpacing: "-0.02em", lineHeight: 1.05 }}
        >
          IMPLEMENTATION DETAIL
        </h2>

        <div className="space-y-0 border-t border-white/10">
          {whatIBuilt.map((item) => (
            <div key={item.case} className="py-10 border-b border-white/10 grid grid-cols-1 md:grid-cols-[140px_1fr] gap-8">
              <div>
                <div className="text-xs font-mono mb-1" style={{ color: "hsl(12, 100%, 46%)" }}>{item.case}</div>
                <div className="text-white font-semibold leading-snug" style={{ fontSize: "0.9rem" }}>
                  {item.title}
                </div>
              </div>
              <ul className="space-y-3">
                {item.bullets.map((b, i) => (
                  <li key={i} className="flex gap-3">
                    <span style={{ color: "hsl(12, 100%, 46%)", fontSize: "0.75rem", marginTop: "4px", flexShrink: 0 }}>→</span>
                    <span className="text-white/65 leading-relaxed" style={{ fontSize: "0.87rem", fontWeight: 400 }}>
                      {b}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Thesis callout */}
        <div
          className="mt-16 p-10 border-l-4"
          style={{ borderColor: "hsl(12, 100%, 46%)", background: "#1a1a1a" }}
        >
          <p className="text-white/40 text-xs tracking-widest uppercase mb-4">What all examples have in common</p>
          <p
            className="text-white leading-relaxed"
            style={{ fontSize: "1.1rem", fontWeight: 400 }}
          >
            I repeatedly work in the gap between what customers experience and what teams need to execute.
            My value is not limited to design, marketing, AI, or operations individually. It is the ability
            to connect them into systems that can scale.
          </p>
        </div>
      </div>
    </section>
  );
}
