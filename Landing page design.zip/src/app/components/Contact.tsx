import { useState } from "react";

export function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", org: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section
      id="contact"
      style={{ background: "hsl(12, 100%, 46%)", fontFamily: "'gopher', sans-serif" }}
      className="py-28 px-8 md:px-14 border-t border-white/20"
    >
      <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-[1fr_1.1fr] gap-20">
        {/* Left */}
        <div>
          <p className="text-white/50 text-xs tracking-widest uppercase mb-4">Contact</p>
          <h2
            className="text-white mb-6"
            style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 900, letterSpacing: "-0.02em", lineHeight: 1.05 }}
          >
            LET'S WORK TOGETHER
          </h2>
          <p className="text-white/75 leading-relaxed mb-10" style={{ fontWeight: 400, fontSize: "0.97rem" }}>
            I'm strongest in environments where the business problem is cross-functional: a brand needs
            sharper positioning, marketing needs to become a system, AI needs practical implementation,
            and operations need fewer heroic cleanup weeks.
          </p>
          <div className="space-y-3">
            <div>
              <span className="text-white/50 text-xs uppercase tracking-widest block mb-0.5">Email</span>
              <a
                href="mailto:pharis.amanda@gmail.com"
                className="text-white font-semibold hover:opacity-80 transition-opacity"
                style={{ fontSize: "0.95rem" }}
              >
                pharis.amanda@gmail.com
              </a>
            </div>
            <div>
              <span className="text-white/50 text-xs uppercase tracking-widest block mb-0.5">Phone</span>
              <a href="tel:6783677387" className="text-white/80 hover:opacity-80 transition-opacity" style={{ fontSize: "0.95rem", fontWeight: 400 }}>
                678-367-7387
              </a>
            </div>
            <div>
              <span className="text-white/50 text-xs uppercase tracking-widest block mb-0.5">Portfolio</span>
              <span className="text-white font-semibold" style={{ fontSize: "0.95rem" }}>pharis.design</span>
            </div>
            <div>
              <span className="text-white/50 text-xs uppercase tracking-widest block mb-0.5">Location</span>
              <span className="text-white/80" style={{ fontSize: "0.95rem", fontWeight: 400 }}>Vancouver, WA · Open to remote & relocation</span>
            </div>
          </div>
        </div>

        {/* Form */}
        {sent ? (
          <div className="flex flex-col justify-center">
            <p className="text-white text-xs tracking-widest uppercase mb-4 opacity-50">Sent</p>
            <p className="text-white leading-relaxed" style={{ fontSize: "1.1rem", fontWeight: 400 }}>
              Message received. I review inquiries personally and will follow up shortly.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {[
              { id: "name", label: "Your Name", type: "text", placeholder: "Jane Smith" },
              { id: "org", label: "Organization", type: "text", placeholder: "Company or context" },
              { id: "email", label: "Email", type: "email", placeholder: "jane@company.com" },
            ].map((f) => (
              <div key={f.id}>
                <label
                  htmlFor={f.id}
                  className="block text-white/50 text-xs tracking-widest uppercase mb-1.5"
                >
                  {f.label}
                </label>
                <input
                  id={f.id}
                  type={f.type}
                  required
                  placeholder={f.placeholder}
                  value={(form as any)[f.id]}
                  onChange={(e) => setForm({ ...form, [f.id]: e.target.value })}
                  className="w-full px-4 py-3 border-b bg-transparent outline-none text-white placeholder-white/30 text-sm transition-colors focus:border-white"
                  style={{ borderColor: "rgba(255,255,255,0.3)" }}
                />
              </div>
            ))}
            <div>
              <label
                htmlFor="message"
                className="block text-white/50 text-xs tracking-widest uppercase mb-1.5"
              >
                Message
              </label>
              <textarea
                id="message"
                required
                rows={4}
                placeholder="Tell me about the problem you're trying to solve..."
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full px-4 py-3 border-b bg-transparent outline-none text-white placeholder-white/30 text-sm transition-colors focus:border-white resize-none"
                style={{ borderColor: "rgba(255,255,255,0.3)" }}
              />
            </div>
            <button
              type="submit"
              className="w-full py-4 text-sm font-semibold tracking-widest uppercase transition-opacity hover:opacity-90"
              style={{ background: "#ffffff", color: "hsl(12, 100%, 46%)" }}
            >
              Send Message
            </button>
          </form>
        )}
      </div>
    </section>
  );
}
