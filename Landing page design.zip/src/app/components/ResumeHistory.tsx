const jobs = [
  {
    company: "CustomBoxes.io",
    title: "Creative Director, Operations Leader & AI Systems Strategist",
    period: "2021 – Present",
    note: "Founding team",
    bullets: [
      "Helped scale business operations to more than $1M in revenue within the company's first two operational years.",
      "Increased customer retention to a 46% repeat purchase rate through customer experience and lifecycle marketing.",
      "Improved website conversion performance to approximately 4% through funnel optimization and customer journey improvements.",
      "Built and managed a subscriber ecosystem exceeding 20,000 contacts through email marketing and content strategies.",
      "Designed and implemented AI-assisted business workflows across marketing, operations, customer communication, research, and planning.",
      "Built internal applications, calculators, and decision-support tools that streamlined operational processes and reduced manual effort.",
      "Developed custom GPT-based systems to support content creation, analysis, problem solving, and organizational productivity.",
    ],
  },
  {
    company: "Create My Cookbook",
    title: "UX Consultant",
    period: "2020 – 2021",
    note: "",
    bullets: [
      "Advised leadership on information architecture, user experience strategy, and customer journey optimization.",
      "Improved conversion rates, completion rates, and average order value through UX recommendations and testing.",
      "Collaborated with stakeholders to identify friction points and streamline customer workflows.",
    ],
  },
  {
    company: "Brandable Box (Pratt Industries)",
    title: "Associate Creative Director",
    period: "2018 – 2021",
    note: "",
    bullets: [
      "Co-led launch and growth of an e-commerce packaging brand projected to exceed $1M in annual revenue.",
      "Reduced production quality issues from approximately 30% to 1% through implementation of a digital fabrication review and QA process.",
      "Directed branding, customer experience, digital initiatives, and production workflows.",
      "Managed and mentored design, production, and digital team members.",
    ],
  },
  {
    company: "Southern Kitchen | Cox Media Group",
    title: "Senior Designer → Art Director",
    period: "2017 – 2018",
    note: "",
    bullets: [
      "Directed redesign of digital customer experiences integrating content, commerce, SEO, and audience growth strategies.",
      "Led migration and implementation of marketing automation infrastructure.",
      "Managed creative teams, contractors, agencies, and development partners.",
    ],
  },
  {
    company: "KEH Camera",
    title: "Graphic Designer",
    period: "2015 – 2016",
    note: "",
    bullets: [
      "Supported e-commerce platform modernization including website redesign and UX improvements.",
      "Led email marketing automation efforts contributing to a 61% increase in revenue from the email channel.",
      "Developed lifecycle marketing strategies and automated customer communication programs.",
    ],
  },
  {
    company: "Earlier Experience",
    title: "Graphic Designer / Junior Designer",
    period: "2012 – 2015",
    note: "The Ivory Company · Vision Stairways & Millwork",
    bullets: [],
  },
];

export function ResumeHistory() {
  return (
    <section
      style={{ background: "#111111", fontFamily: "'gopher', sans-serif" }}
      className="py-28 px-8 md:px-14 border-t border-white/10"
    >
      <div className="max-w-5xl mx-auto">
        <p className="text-white/40 text-xs tracking-widest uppercase mb-4">Career History</p>
        <h2
          className="text-white mb-16"
          style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 900, letterSpacing: "-0.02em", lineHeight: 1.05 }}
        >
          EXPERIENCE
        </h2>

        <div className="space-y-0">
          {jobs.map((job, i) => (
            <div
              key={i}
              className="grid grid-cols-1 md:grid-cols-[220px_1fr] gap-6 md:gap-12 py-10 border-t border-white/10 first:border-t-0"
            >
              {/* Left: meta */}
              <div className="shrink-0">
                <div
                  className="text-white font-semibold mb-1 leading-snug"
                  style={{ fontSize: "0.88rem" }}
                >
                  {job.company}
                </div>
                <div
                  className="text-xs mb-2"
                  style={{ color: "hsl(12, 100%, 46%)", fontWeight: 600 }}
                >
                  {job.period}
                </div>
                {job.note && (
                  <div className="text-white/35 text-xs">{job.note}</div>
                )}
              </div>

              {/* Right: content */}
              <div>
                <div
                  className="text-white mb-5 leading-snug"
                  style={{ fontSize: "1rem", fontWeight: 600 }}
                >
                  {job.title}
                </div>
                {job.bullets.length > 0 && (
                  <ul className="space-y-2.5">
                    {job.bullets.map((b, bi) => (
                      <li key={bi} className="flex gap-3">
                        <span style={{ color: "hsl(12, 100%, 46%)", fontSize: "0.75rem", marginTop: "4px", flexShrink: 0 }}>→</span>
                        <span
                          className="text-white/60 leading-relaxed"
                          style={{ fontSize: "0.87rem", fontWeight: 400 }}
                        >
                          {b}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Achievements callout */}
        <div
          className="mt-16 grid grid-cols-2 md:grid-cols-3 border-t border-l border-white/10"
        >
          {[
            { value: "$1M+", label: "Revenue scaled at CustomBoxes.io" },
            { value: "46%", label: "Repeat purchase rate achieved" },
            { value: "4%", label: "Website conversion rate" },
            { value: "20K+", label: "Subscriber ecosystem built" },
            { value: "30%→1%", label: "Manufacturing defects reduced" },
            { value: "+61%", label: "Email-driven revenue at KEH Camera" },
          ].map((m) => (
            <div
              key={m.label}
              className="border-b border-r border-white/10 px-7 py-7"
            >
              <div
                className="text-white"
                style={{ fontSize: "1.8rem", fontWeight: 700, lineHeight: 1, color: "hsl(12, 100%, 46%)" }}
              >
                {m.value}
              </div>
              <div
                className="text-white/45 mt-1.5 leading-snug"
                style={{ fontSize: "0.72rem", fontWeight: 400 }}
              >
                {m.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
