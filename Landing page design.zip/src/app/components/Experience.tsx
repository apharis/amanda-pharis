import { useState } from "react";

const cases = [
  {
    id: "01",
    title: "Revenue Operating System",
    tags: ["Strategy", "Growth", "Operations", "Executive Cadence"],
    problem: "Too many active initiatives across website, email, AI, partnerships, and operations created execution risk. Growth goals existed, but execution needed focus and cadence.",
    move: "Created a theme-based operating portfolio with only two active themes at a time: revenue infrastructure, product/automation, operations systemization, and brand authority.",
    cadence: "Established a Monday/Wednesday/Friday rhythm: KPI review, blocker removal, shipped work, metric movement, and a kill/continue/stop decision loop.",
    principle: "No status theater. The cadence focused on what shipped, what moved metrics, and what to stop.",
    metrics: [
      { value: "+25–40%", label: "CVR improvement target" },
      { value: "60%+", label: "Email revenue from flows target" },
      { value: "3%", label: "Site CVR target" },
      { value: "0", label: "Heroic scramble weeks goal" },
    ],
    signal: "Executive prioritization and operating discipline.",
  },
  {
    id: "02",
    title: "Lifecycle Revenue Engine",
    tags: ["Lifecycle Marketing", "CRO", "Retention", "Segmentation"],
    problem: "Campaign traffic and one-time buyers were not consistently routed into lifecycle paths. Email was too campaign-dependent and repeat ordering was underdeveloped.",
    move: "Treat email as a revenue system: Welcome, Post-Purchase, Reorder, Winback, segmentation, and Autoship messaging should reinforce one economic story.",
    cadence: "Rebuilt flows, added Autoship messaging, expanded behavioral triggers, and aligned campaigns to flow handoffs.",
    principle: "Reorder conversion remained low, revealing that messaging alone wasn't enough — reordering needed to become structural.",
    metrics: [
      { value: "35%→56%", label: "Flow share of email revenue" },
      { value: "+560%", label: "Flow volume increase" },
      { value: "+66%", label: "Email revenue growth, directional" },
      { value: "1.73%", label: "Reorder CVR identified as leak" },
    ],
    signal: "Revenue system design and funnel diagnosis.",
  },
  {
    id: "03",
    title: "AI Systems & Internal Tooling",
    tags: ["AI Strategy", "Internal Apps", "Workflow Automation", "Knowledge Systems"],
    problem: "Manual decisions and tribal knowledge created bottlenecks. The business had rules-heavy work across prepress, design, customer service, production, and marketing.",
    move: "Create role-specific GPTs and tools for customer service, email, production design, strategic decision support, overbox logic, and prepress questions.",
    cadence: "Prioritized use cases by volume and operational ROI: barcode handling, dieline logic, layout assistance, production notes, and customer communication.",
    principle: "AI is a doer and accelerator, not a substitute for human brand judgment. The strongest systems preserve context, taste, and customer empathy.",
    metrics: [
      { value: "4", label: "Internal GPT systems deployed" },
      { value: "↓", label: "Repetitive support hours reduced" },
      { value: "↑", label: "Prepress resolution speed" },
      { value: "0", label: "Brand quality compromises" },
    ],
    signal: "Practical AI adoption connected to business value.",
  },
  {
    id: "04",
    title: "Tiered Shopify Commerce Build",
    tags: ["Shopify", "Digital Product", "UX", "Commerce Architecture"],
    problem: "A packaging concept needed a clear ecommerce architecture. Customers needed an easier path from idea to purchase across different service tiers.",
    move: "Build a Good/Better/Best-style product structure that maps customer complexity to the right purchase path.",
    cadence: "Used Shopify Dawn, product templates, line item properties, app extensions where necessary, and a structured launch checklist.",
    principle: "Make the offer feel simple: text-only, logo upload, growth branding, or full-service support.",
    metrics: [
      { value: "19", label: "Theme files in section pack" },
      { value: "4", label: "Tiered product templates" },
      { value: "5 wks", label: "Launch timeline model" },
      { value: "$91–128", label: "Estimated monthly app stack" },
    ],
    signal: "Digital product and commerce implementation strategy.",
  },
  {
    id: "05",
    title: "Partnership GTM System",
    tags: ["GTM", "Partnerships", "Segmentation", "Attribution"],
    problem: "A partner opportunity needed segmentation, messaging, tracking, and a launch path — and a 360-degree system that would create value for both audiences.",
    move: "Prioritize high-relevance segments: customers buying mailers, cube boxes, food-related categories, and shipping/fulfillment packaging.",
    cadence: "Landing page updates, partner email template, segmented customer email, light social support, optional retargeting, and UTM attribution.",
    principle: "If performance was strong, develop a bundled cold-chain shipping kit: box, liner, and ice pack.",
    metrics: [
      { value: "5", label: "GTM channels coordinated" },
      { value: "4", label: "Audience segments defined" },
      { value: "UTM", label: "Full attribution model built" },
      { value: "1", label: "Product expansion path mapped" },
    ],
    signal: "Brand, partnership, lifecycle, and channel planning.",
  },
];

export function Experience() {
  const [active, setActive] = useState(0);
  const c = cases[active];

  return (
    <section
      id="work"
      style={{ background: "#111111", fontFamily: "'gopher', sans-serif" }}
      className="py-28 px-8 md:px-14"
    >
      <div className="max-w-5xl mx-auto">
        <p className="text-white/40 text-xs tracking-widest uppercase mb-4">Selected Case Studies</p>
        <h2
          className="text-white mb-14"
          style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 900, letterSpacing: "-0.02em", lineHeight: 1.05 }}
        >
          FIVE CASE STUDIES
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-[260px_1fr] gap-0 border border-white/10">
          {/* Tabs */}
          <div className="border-r border-white/10">
            {cases.map((item, i) => (
              <button
                key={item.id}
                onClick={() => setActive(i)}
                className="w-full text-left px-6 py-5 border-b border-white/10 transition-colors"
                style={{
                  background: active === i ? "hsl(12, 100%, 46%)" : "transparent",
                  borderLeft: active === i ? "3px solid hsl(12, 100%, 46%)" : "3px solid transparent",
                }}
              >
                <div
                  className="text-xs mb-1 font-mono"
                  style={{ color: active === i ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.3)" }}
                >
                  {item.id}
                </div>
                <div
                  className="text-sm leading-snug"
                  style={{
                    color: active === i ? "#ffffff" : "rgba(255,255,255,0.55)",
                    fontWeight: active === i ? 600 : 400,
                  }}
                >
                  {item.title}
                </div>
              </button>
            ))}
          </div>

          {/* Detail */}
          <div className="p-10" style={{ background: "#1a1a1a" }}>
            <div className="flex flex-wrap gap-2 mb-6">
              {c.tags.map((t) => (
                <span
                  key={t}
                  className="px-2.5 py-1 text-xs uppercase tracking-wider"
                  style={{ background: "hsl(12, 100%, 46%)", color: "#ffffff" }}
                >
                  {t}
                </span>
              ))}
            </div>

            <h3
              className="text-white mb-8"
              style={{ fontSize: "1.5rem", fontWeight: 700, lineHeight: 1.2 }}
            >
              {c.id}. {c.title}
            </h3>

            <div className="grid grid-cols-2 gap-6 mb-8">
              {c.metrics.map((m) => (
                <div key={m.label} className="border-l-2 pl-4" style={{ borderColor: "hsl(12, 100%, 46%)" }}>
                  <div className="text-white" style={{ fontSize: "1.4rem", fontWeight: 700, lineHeight: 1 }}>
                    {m.value}
                  </div>
                  <div className="text-white/50 mt-1" style={{ fontSize: "0.72rem", fontWeight: 400 }}>
                    {m.label}
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-5 border-t border-white/10 pt-6">
              {[
                { label: "Business Constraint", text: c.problem },
                { label: "Strategic Move", text: c.move },
                { label: "Execution", text: c.cadence },
                { label: "Leadership Principle", text: c.principle },
              ].map(({ label, text }) => (
                <div key={label}>
                  <div className="text-xs tracking-widest uppercase mb-1" style={{ color: "hsl(12, 100%, 46%)", fontWeight: 600 }}>
                    {label}
                  </div>
                  <p className="text-white/70 leading-relaxed" style={{ fontSize: "0.88rem", fontWeight: 400 }}>
                    {text}
                  </p>
                </div>
              ))}
            </div>

            <div
              className="mt-6 pt-5 border-t border-white/10 text-xs uppercase tracking-widest"
              style={{ color: "rgba(255,255,255,0.3)" }}
            >
              Leadership signal → <span className="text-white/60">{c.signal}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
