const principles = [
  "Make buying obvious, reordering automatic, and production easier.",
  "Use AI where it reduces ambiguity, not where it creates more review work.",
  "Treat brand as a business system, not a decoration layer.",
  "Prioritize the few actions that move metrics; park or kill the rest.",
  "Design tools and processes that make teams calmer, faster, and more consistent.",
];

const roles = [
  {
    role: "Head / Director of Brand",
    proof: "Brand positioning, CX clarity, GTM systems, customer education, lifecycle messaging.",
    angle: "A brand leader who can connect creative direction to revenue and customer behavior.",
  },
  {
    role: "Director of Marketing / Growth",
    proof: "Flow revenue improvements, segmentation, CRO, paid traffic quality, partnerships.",
    angle: "A growth leader who understands owned revenue, funnel diagnosis, and conversion clarity.",
  },
  {
    role: "Chief of Staff / BizOps",
    proof: "Operating cadence, decision gates, SOP ownership, kill-list discipline, cross-functional alignment.",
    angle: "A business operator who creates focus and reduces organizational drag.",
  },
  {
    role: "Director of AI Innovation",
    proof: "Internal GPT ecosystem, AI prepress roadmap, AI-assisted apps, calculators, and workflow strategy.",
    angle: "An AI adoption leader who ties tools to labor savings, quality, and customer experience.",
  },
];

export function Achievements() {
  return (
    <section
      style={{ background: "hsl(12, 100%, 46%)", fontFamily: "'gopher', sans-serif" }}
      className="py-28 px-8 md:px-14 border-t border-white/20"
    >
      <div className="max-w-5xl mx-auto">
        {/* Leadership thesis */}
        <p className="text-white/50 text-xs tracking-widest uppercase mb-4">Leadership Thesis</p>
        <h2
          className="text-white mb-6"
          style={{ fontSize: "clamp(1.6rem, 4vw, 3rem)", fontWeight: 900, letterSpacing: "-0.02em", lineHeight: 1.1 }}
        >
          ROLE TRANSLATION
        </h2>
        <p
          className="text-white/80 max-w-2xl leading-relaxed mb-16"
          style={{ fontSize: "1rem", fontWeight: 400 }}
        >
          Modern creative leadership is no longer only about taste. It is about building the systems that
          help a company communicate clearly, sell intelligently, operate consistently, and use
          technology without losing human insight.
        </p>

        {/* Role table */}
        <div className="border-t border-white/20 mb-20">
          {roles.map((r) => (
            <div
              key={r.role}
              className="grid grid-cols-1 md:grid-cols-[200px_1fr_1fr] gap-6 py-7 border-b border-white/20"
            >
              <div className="text-white font-semibold" style={{ fontSize: "0.9rem" }}>{r.role}</div>
              <div className="text-white/60" style={{ fontSize: "0.85rem", fontWeight: 400 }}>{r.proof}</div>
              <div className="text-white/80 italic" style={{ fontSize: "0.85rem", fontWeight: 400 }}>{r.angle}</div>
            </div>
          ))}
        </div>

        {/* Management principles */}
        <p className="text-white/50 text-xs tracking-widest uppercase mb-8">Management Principles</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border-t border-l border-white/20">
          {principles.map((p, i) => (
            <div
              key={i}
              className="px-8 py-7 border-b border-r border-white/20 flex gap-4"
            >
              <span className="text-white/25 font-mono text-xs mt-0.5 shrink-0">
                {String(i + 1).padStart(2, "0")}
              </span>
              <p className="text-white/80 leading-relaxed" style={{ fontSize: "0.88rem", fontWeight: 400 }}>
                {p}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
