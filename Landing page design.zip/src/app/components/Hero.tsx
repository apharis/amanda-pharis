export function Hero() {
  return (
    <section
      style={{ background: "hsl(12, 100%, 46%)", fontFamily: "'gopher', sans-serif" }}
      className="min-h-screen flex flex-col"
    >
      {/* Nav */}
      <nav className="flex items-center justify-between px-8 md:px-14 py-8">
        <span className="text-white text-sm font-semibold tracking-widest uppercase opacity-80">
          Amanda Pharis
        </span>
        <div className="flex gap-8">
          {["Work", "About", "Contact"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="text-white text-xs tracking-widest uppercase opacity-60 hover:opacity-100 transition-opacity"
            >
              {item}
            </a>
          ))}
        </div>
      </nav>

      {/* Main hero content */}
      <div className="flex-1 flex flex-col justify-center px-8 md:px-14 pb-16 pt-10">
        <div className="max-w-5xl">
          <p className="text-white text-sm tracking-widest uppercase opacity-60 mb-6">
            Brand · Growth Systems · AI Innovation
          </p>
          <h1
            className="text-white leading-none mb-8"
            style={{
              fontSize: "clamp(3.5rem, 10vw, 9rem)",
              fontWeight: 900,
              letterSpacing: "-0.03em",
            }}
          >
            Communicate,
            <br />
            <span style={{ opacity: 0.35 }}>don't decorate.</span>
          </h1>
          <p
            className="text-white max-w-2xl leading-relaxed mb-10"
            style={{ fontSize: "1.1rem", fontWeight: 400, opacity: 0.85 }}
          >
            I build business systems where brand, customer experience, operations, and technology meet.
            My strongest work translates ambiguous problems into practical operating models,
            revenue systems, AI-enabled workflows, and customer experiences that teams can actually use.
          </p>
          <div className="flex flex-wrap gap-4">
            <a
              href="#work"
              className="px-7 py-3.5 text-sm font-semibold tracking-wider uppercase transition-all hover:opacity-90"
              style={{ background: "#ffffff", color: "hsl(12, 100%, 46%)" }}
            >
              View Case Studies
            </a>
            <a
              href="#about"
              className="px-7 py-3.5 text-sm font-semibold tracking-wider uppercase border border-white text-white transition-all hover:bg-white hover:text-[hsl(12, 100%, 46%)]"
            >
              About + Resume
            </a>
          </div>
        </div>
      </div>

      {/* Bottom stat strip */}
      <div className="border-t border-white/20 grid grid-cols-2 md:grid-cols-4">
        {[
          { value: "12+", label: "Years across brand, ecommerce & ops" },
          { value: "$1M+", label: "Startup revenue milestone contributed to" },
          { value: "+21 pts", label: "Flow revenue share improvement" },
          { value: "2×", label: "Add-to-cart improvement in tested funnel" },
        ].map((s) => (
          <div
            key={s.label}
            className="px-8 py-6 border-r border-white/20 last:border-r-0"
          >
            <div
              className="text-white"
              style={{ fontSize: "1.8rem", fontWeight: 700, lineHeight: 1 }}
            >
              {s.value}
            </div>
            <div
              className="text-white mt-1.5 leading-snug"
              style={{ fontSize: "0.72rem", opacity: 0.55, fontWeight: 400 }}
            >
              {s.label}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
