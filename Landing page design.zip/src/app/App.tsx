import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { ResumeHistory } from "./components/ResumeHistory";
import { Experience } from "./components/Experience";
import { Achievements } from "./components/Achievements";
import { Testimonials } from "./components/Testimonials";
import { Contact } from "./components/Contact";

export default function App() {
  return (
    <div style={{ fontFamily: "'gopher', sans-serif" }}>
      <Hero />
      <About />
      <ResumeHistory />
      <Experience />
      <Achievements />
      <Testimonials />
      <Contact />
      <footer
        style={{ background: "#111111", fontFamily: "'gopher', sans-serif" }}
        className="px-8 md:px-14 py-8 border-t border-white/10 flex flex-wrap items-center justify-between gap-4"
      >
        <span className="text-white/30 text-xs tracking-widest uppercase">
          © 2024 Amanda Pharis
        </span>
        <span className="text-white/30 text-xs">
          Selected examples generalized for confidentiality
        </span>
      </footer>
    </div>
  );
}
