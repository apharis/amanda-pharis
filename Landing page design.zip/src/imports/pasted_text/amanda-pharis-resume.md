AMANDA PHARIS | Business Builder | Brand & Marketing Leader | AI Systems Strategist
Vancouver, WA | Open to Remote & Relocation
pharis.amanda@gmail.com | pharis.design | 678-367-7387
PROFESSIONAL PROFILE
Business leader with 12+ years of experience building brands, operational systems, digital products, and customer experiences across e-commerce, manufacturing, media, and startup environments.
Known for translating complex business challenges into scalable solutions through a combination of strategic thinking, operational leadership, creative direction, and AI-enabled innovation. Experienced in leading cross-functional teams, developing revenue-generating marketing systems, building internal business tools, and implementing technology that accelerates growth without sacrificing customer experience or brand quality.
As a founding leader of CustomBoxes.io, helped establish operational infrastructure, customer acquisition systems, production workflows, and brand strategy that contributed to scaling the company to more than $1M in revenue within its first two years of operation.
CORE LEADERSHIP AREAS

Business Operations & Process Design
AI Systems & Workflow Innovation
Brand Strategy & Positioning
Marketing Leadership
E-commerce Growth
Customer Experience Optimization
Team Leadership & Mentorship
Digital Product Development
Conversion Rate Optimization
Email Marketing & Automation
Shopify & Commerce Strategy
Cross-Functional Program Leadership


PROFESSIONAL EXPERIENCE
CUSTOMBOXES.IO
Creative Director, Operations Leader & AI Systems Strategist
2021 – Present
Founding leadership team member responsible for brand strategy, operations, marketing, customer experience, production systems, AI implementation, and organizational growth.
BUSINESS IMPACT
• Helped scale business operations to more than $1M in revenue within the company's first two operational years.
• Established operational frameworks spanning prepress, print production, quality control, fulfillment, and customer support.
• Increased customer retention to a 46% repeat purchase rate through customer experience and lifecycle marketing initiatives.
• Improved website conversion performance to approximately 4% through funnel optimization and customer journey improvements.
• Built and managed a subscriber ecosystem exceeding 20,000 contacts through email marketing and content strategies.
• Designed brand positioning centered on sustainability, entrepreneurship, and small-business advocacy.
• Hired, trained, managed, and mentored employees across multiple locations and remote teams.
AI, PRODUCT & INNOVATION
• Designed and implemented AI-assisted business workflows across marketing, operations, customer communication, research, and planning functions.
• Built internal applications, calculators, and decision-support tools that streamlined operational processes and reduced manual effort.
• Developed custom GPT-based systems to support content creation, analysis, problem solving, and organizational productivity.
• Created front-end business applications and digital experiences using AI-assisted development workflows.
• Leveraged AI to accelerate execution speed while maintaining strategic thinking, brand consistency, and human-centered customer experiences.
• Championed AI adoption across teams through training, workflow development, and practical implementation strategies.
CREATE MY COOKBOOK
UX Consultant
2020 – 2021
• Advised leadership on information architecture, user experience strategy, and customer journey optimization.
• Improved opportunities for conversion, completion rates, and average order value through UX recommendations and testing initiatives.
• Collaborated with stakeholders to identify friction points and streamline customer workflows.
BRANDABLE BOX (PRATT INDUSTRIES)
Associate Creative Director
2018 – 2021
• Co-led launch and growth of an e-commerce packaging brand projected to exceed $1M in annual revenue.
• Directed branding, customer experience, digital initiatives, and production workflows.
• Reduced production quality issues from approximately 30% to 1% through implementation of a digital fabrication review and QA process.
• Managed and mentored design, production, and digital team members.
• Collaborated with leadership on strategic initiatives supporting growth and operational excellence.
SOUTHERN KITCHEN | COX MEDIA GROUP
Senior Designer → Art Director
2017 – 2018
• Directed redesign of digital customer experiences integrating content, commerce, SEO, and audience growth strategies.
• Led migration and implementation of marketing automation infrastructure.
• Managed creative teams, contractors, agencies, and development partners.
• Developed integrated marketing initiatives supporting audience growth and engagement objectives.
KEH CAMERA
Graphic Designer
2015 – 2016
• Supported e-commerce platform modernization initiatives including website redesign and user experience improvements.
• Led email marketing automation efforts that contributed to a 61% increase in revenue from the email channel.
• Developed lifecycle marketing strategies and automated customer communication programs.
EARLIER EXPERIENCE
Graphic Designer
The Ivory Company | 2013 – 2015
Junior Designer
Vision Stairways & Millwork | 2012 – 2013
SELECTED ACHIEVEMENTS
• Scaled startup operations contributing to $1M+ revenue growth.
• Improved customer retention to 46% repeat purchase rate.
• Increased website conversion performance to 4%.
• Built and managed a 20,000+ subscriber marketing ecosystem.
• Reduced manufacturing quality issues from 30% to 1%.
• Increased email-driven revenue by 61%.
• Built internal AI systems, workflow tools, calculators, and operational applications.
• Led teams across creative, production, marketing, and operational functions.
TECHNOLOGY & PLATFORMS
AI & Automation
ChatGPT, Claude, Codex, Custom GPT Development, AI Workflow Design, AI-Assisted Product Development
Commerce & Marketing
Shopify, Klaviyo, ActiveCampaign, Mailchimp, Bronto, Constant Contact
Design & Product
Figma, Adobe Creative Cloud, Photoshop, Illustrator, InDesign, After Effects
Analytics & Web
Google Analytics, HTML/CSS, Conversion Optimization, UX Strategy
EDUCATION
Bachelor of Fine Arts, Graphic Design
Art Institute of Atlanta
Cum Laude

