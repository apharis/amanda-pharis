AMANDA PHARIS
Leadership Portfolio
Brand, Growth Systems & AI Innovation
Selected case studies from startup growth, lifecycle marketing, digital product development, AI systems, and
operational transformation.
Portfolio positioning
I build business systems where brand, customer experience, operations, and technology meet. My
strongest work translates ambiguous problems into practical operating models, revenue systems, AIenabled workflows, and customer experiences that teams can actually use.
12+
years across brand,
ecommerce & operations
$1M+
startup revenue milestone
contributed to
+21 pts
flow revenue share
improvement
2x
add-to-cart improvement in
tested funnel work
Best-fit roles
Head / Director of Brand
Brand systems, positioning, CX, content,
ecommerce growth.
Chief of Staff / BizOps
Operating cadence, prioritization, crossfunctional execution.
Director of AI Innovation
Practical AI adoption, internal tooling,
automation strategy.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
EXECUTIVE SNAPSHOT
A portfolio of business systems, not just
creative work
This portfolio is built from five sanitized case studies. The goal is to show how I identify business
constraints, design a practical system, lead cross-functional execution, and connect creative decisions to
measurable outcomes.
WHAT I AM BEST AT
Turning scattered ideas, friction points, and business
goals into operating systems that teams can run.
HOW I WORK
I use customer insight, data, AI tooling, and creative
strategy to move from ambiguity to execution.
WHY THIS MATTERS
Fast-growing companies often do not need more ideas.
They need the right ideas prioritized, operationalized, and
measured.
WHAT THIS PORTFOLIO PROVES
Brand leadership, lifecycle marketing, AI systems
thinking, ecommerce UX, and operations can be one
integrated growth function.
Five case studies
CASE BUSINESS PROBLEM LEADERSHIP SIGNAL
01. Revenue Operating System Growth goals existed, but execution
needed focus and cadence.
Executive prioritization and operating
discipline.
02. Lifecycle Revenue Engine Email was too campaign-dependent and
repeat ordering was underdeveloped.
Revenue system design and funnel
diagnosis.
03. AI Systems & Internal Tooling Manual decisions and tribal knowledge
created bottlenecks.
Practical AI adoption connected to
business value.
04. Tiered Shopify Commerce Build A packaging offer needed a clear
ecommerce architecture.
Digital product and commerce
implementation strategy.
05. Partnership GTM System A partner opportunity needed
segmentation, messaging, tracking, and a
launch path.
Brand, partnership, lifecycle, and channel
planning.
Confidentiality note
Examples are generalized and sanitized for external use. Metrics are included at the level needed to show
leadership impact without exposing sensitive operational details.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
01
Building a 2026 Revenue
Operating System
Turning goals into a focused weekly management
cadence
STRATEGY | GROWTH | OPERATIONS | EXECUTIVE CADENCE
Context: the business needed a predictable revenue machine, not a pile of disconnected campaigns, website
edits, AI ideas, and operational fire drills. The work began by compressing the business into a few primary
outcomes: improve conversion, strengthen owned revenue, make reordering easier, and reduce operational
ambiguity.
BUSINESS CONSTRAINT
Too many active initiatives across website, email, AI,
partnerships, and operations created execution risk.
STRATEGIC MOVE
Created a theme-based operating portfolio with only two
active themes at a time: revenue infrastructure,
product/automation, operations systemization, and brand
authority.
OPERATING CADENCE
Established a Monday/Wednesday/Friday rhythm: KPI
review, blocker removal, shipped work, metric
movement, and a kill/continue/stop decision loop.
LEADERSHIP PRINCIPLE
No status theater. The cadence focused on what shipped,
what moved metrics, and what to stop.
+25-40%
CVR improvement target
60%+
email revenue from flows
target
3%
site CVR target
0
heroic scramble weeks goal
What I built
 Primary KPI hierarchy covering site conversion, email revenue, PDP clarity, Autoship behavior, paid
traffic quality, and operational readiness.
 Ninety-day control plan focused on two objectives: lock revenue predictability and remove operational
ambiguity.
 Decision gates for what to start, continue, stop, freeze, or kill so new ideas did not derail execution.
 SOP ownership framework for peak coverage, prepress exceptions, barcode repair, AI-ready prepress,
and customer service quality thresholds.
Executive takeaway
This case study shows my ability to create a management system that helps teams prioritize. The work is not
just strategic planning; it is the translation layer between leadership goals and weekly execution.
Head of Brand
Connects brand, website clarity, and
customer education to revenue.
Chief of Staff
Creates cadence, decisions, ownership,
and focus.
AI Innovation
Gates automation work against
operational ROI instead of novelty.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
02
Lifecycle Revenue Engine
Shifting email from campaign pressure to automated
revenue infrastructure
LIFECYCLE MARKETING | CRO | RETENTION | SEGMENTATION
Context: the company had audience, traffic, and campaign activity, but lifecycle revenue needed to become
more predictable. The work focused on reducing campaign dependency, strengthening email flows, and
making reordering and Autoship structurally easier for customers.
PROBLEM
Campaign traffic and one-time buyers were not
consistently routed into lifecycle paths. Customers bought
once, then lacked timely reorder logic.
STRATEGY
Treat email as a revenue system: Welcome, Post-Purchase,
Reorder, Winback, segmentation, and Autoship messaging
should reinforce one economic story.
EXECUTION
Rebuilt flows, added Autoship messaging, expanded
behavioral triggers, and aligned campaigns to flow
handoffs.
NEXT CONSTRAINT IDENTIFIED
Reorder conversion remained low, revealing that
messaging alone was not enough; reordering needed to
become structural.
35% -> 56%
flow share of email revenue
+560%
flow volume increase
+66%
email revenue growth,
directional
1.73%
reorder CVR identified as
leak
Operating model
SEGMENT WHY IT MATTERED LIFECYCLE MOVE
New buyers Highest confusion, lowest conversion Education, ROI framing, future-proofing.
Repeat buyers Trust exists but behavior is still manual Reorder prompts and Subscribe & Save
logic.
High-volume accounts Largest LTV and margin upside Volume economics, account support,
predictable restock.
Lapsed customers Paid acquisition cost already invested Winback with clearer economic re-entry.
Executive takeaway
This case study shows that I do not treat email as a send calendar. I treat it as an owned revenue system
connected to customer behavior, ecommerce UX, and operational capacity.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
03
AI Systems & Internal Tooling
Designing practical AI workflows for marketing,
prepress, customer service, and operations
AI STRATEGY | INTERNAL APPS | WORKFLOW AUTOMATION |
KNOWLEDGE SYSTEMS
Context: the business had rules-heavy work across prepress, design, customer service, production, and
marketing. Much of the value lived in human judgment and undocumented tribal knowledge. The AI
opportunity was not to replace expertise; it was to make expertise faster, clearer, and easier to scale.
AI PHILOSOPHY
AI is a doer and accelerator, not a substitute for human
brand judgment. The strongest systems preserve context,
taste, and customer empathy.
BUSINESS OBJECTIVE
Reduce manual effort in work that does not require
human creativity while protecting quality in work that
does.
SYSTEM DESIGN
Create role-specific GPTs and tools for customer service,
email, production design, strategic decision support,
overbox logic, and prepress questions.
IMPLEMENTATION LENS
Prioritize use cases by volume and operational ROI:
barcode handling, dieline logic, layout assistance,
production notes, and customer communication.
Internal AI ecosystem
TOOL / SYSTEM PURPOSE BUSINESS VALUE
Client Service GPT Answer policy, status, print-rule, and
disruption questions in consistent voice.
Faster response quality and fewer
repetitive human support hours.
Email GPT Create campaigns, test subject lines, apply
segmentation logic, and maintain ROIbased messaging.
Faster lifecycle execution with less
creative bottleneck.
Production Design GPT Codify print rules, dieline logic, ink
constraints, and upgrade reasoning.
Fewer errors and faster onboarding.
Prepress Pro Support technical prepress questions, file
review, and logo recreation workflows.
Faster prepress resolution and more
consistent outcomes.
Broader product concept
 Front-end AI: brand asset scraping, brand intelligence profiles, design variant generation, upgrade
recommendation logic, and ROI-driven page messaging.
 Production AI: print-safe PDF intake, Adobe scripting, prepress QA, template selection, panel logic,
production notes, and version archival.
 Business apps and calculators: internal decision-support tools that reduce manual comparison work and
help teams make faster, more consistent decisions.
Executive takeaway
This case study positions me as a practical AI systems leader: someone who can identify where AI belongs,
where it does not, and how to implement it without losing brand quality or operational control.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
04
Tiered Shopify Commerce Build
Turning a packaging concept into a structured
ecommerce experience
SHOPIFY | DIGITAL PRODUCT | UX | COMMERCE ARCHITECTURE
Context: a packaging concept needed to become a clear, sellable Shopify experience. The work required more
than page design: it needed product architecture, tier positioning, customer input logic, app tradeoffs, launch
sequencing, and QA.
BUSINESS PROBLEM
Customers needed an easier path from idea to purchase
across different service tiers and levels of design support.
COMMERCE STRATEGY
Build a Good/Better/Best-style product structure that maps
customer complexity to the right purchase path.
TECHNICAL APPROACH
Use Shopify Dawn, product templates, line item
properties, app extensions where necessary, and a
structured launch checklist.
CUSTOMER EXPERIENCE GOAL
Make the offer feel simple: text-only, logo upload, growth
branding, or full-service support.
Product architecture
TIER CUSTOMER NEED SYSTEM DECISION
Basic Text-only personalization Native Shopify line item properties for
brand text and font choice.
Standard Logo upload and file review File upload app path, with clear
production limitations.
Premium Digital proof and priority production Consult-style CTA until custom designer
tooling is justified.
Super Premium Full-service branding support Higher-touch sales motion and future
custom studio integration.
19
theme files in section pack
4
tiered product templates
5 weeks
launch timeline model
$91-128/mo
estimated operating app
stack
Executive takeaway
This case study shows that I can translate brand and UX strategy into a practical commerce implementation
plan. I understand the difference between a mockup, a theme, an app constraint, a checkout limitation, and a
launch-ready customer journey.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
05
Partnership GTM System
Launching a co-marketing campaign for cold-chain
packaging
GTM | PARTNERSHIPS | SEGMENTATION | ATTRIBUTION
Context: a cold-chain packaging partner opportunity needed a 360-degree launch system that would create
value for both audiences without blasting irrelevant messages to the full list.
CAMPAIGN OBJECTIVE
Drive insulated packaging adoption among existing
customers while acquiring new box customers from the
partner audience.
AUDIENCE STRATEGY
Prioritize high-relevance segments: customers buying
mailers, cube boxes, food-related categories, and
shipping/fulfillment packaging.
LAUNCH SYSTEM
Landing page updates, partner email template,
CustomBoxes segmented email, light social support,
optional retargeting, and UTM attribution.
PRODUCT EXPANSION PATH
If performance was strong, develop a bundled cold-chain
shipping kit: box, liner, and ice pack.
GTM framework
CHANNEL ROLE IN LAUNCH MEASUREMENT
Landing page Explain the combined solution and route
campaign traffic.
Visits, conversion rate, traffic source.
Customer email Introduce liner upgrade to relevant box
customers.
Open rate, CTR, coupon usage.
Partner email Acquire new packaging customers from
partner audience.
New customers, partner traffic
conversion.
Retargeting Support warm decision-making after page
visit.
Return visits, conversion assist, offer
engagement.
Executive takeaway
This case study shows how I build partnership marketing as a system: offer, audience, page, message,
channel, tracking, and future productization. It is brand work, revenue work, and operations work at the
same time.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
ADDITIONAL EVIDENCE
Mini-case: Productizing production quality
A recurring theme in my work is translating operational constraints into customer-facing clarity. One
example: instead of selling "better ink" or explaining print-head mechanics, I reframed a production
constraint as a premium brand-quality service.
CUSTOMER TRUTH
Customers care about logo sharpness, consistency, brand
perception, and the unboxing experience - not printer
mechanics.
PRODUCTIZED OFFER
Premium Print Assurance: manual artwork review,
enhanced print routing, optimized saturation handling,
and best-available print setup.
ROUTING MODEL
Protected accounts, paid premium upgrades, standard
production, and artwork-based triage.
OPERATIONAL POLICY
Routing decisions account for customer tier, purchased
upgrade, and whether artwork actually benefits from
premium print capacity.
Why it matters
 Protects strategic accounts without making impossible universal promises.
 Creates a paid upgrade path that feels fair and valuable.
 Gives production flexibility while reducing internal ambiguity.
 Turns a technical constraint into a brand-quality positioning opportunity.
What all six examples have in common
I repeatedly work in the gap between what customers experience and what teams need to execute. My
value is not limited to design, marketing, AI, or operations individually. It is the ability to connect
them into systems that can scale.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
ROLE TRANSLATION
How this portfolio maps to target roles
TARGET ROLE PROOF POINTS FROM THIS PORTFOLIO POSITIONING ANGLE
Head / Director of Brand Brand positioning, CX clarity, GTM
systems, customer education, lifecycle
messaging.
A brand leader who can connect creative
direction to revenue and customer
behavior.
Director of Marketing / Growth Flow revenue improvements,
segmentation, CRO, paid traffic quality,
partnerships.
A growth leader who understands owned
revenue, funnel diagnosis, and conversion
clarity.
Chief of Staff / BizOps Operating cadence, decision gates, SOP
ownership, kill-list discipline, crossfunctional alignment.
A business operator who creates focus and
reduces organizational drag.
Director of AI Innovation Internal GPT ecosystem, AI prepress
roadmap, AI-assisted apps, calculators,
and workflow strategy.
An AI adoption leader who ties tools to
labor savings, quality, and customer
experience.
Leadership thesis
Modern creative leadership is no longer only about taste. It is about building the systems that
help a company communicate clearly, sell intelligently, operate consistently, and use
technology without losing human insight.
Management principles
 Make buying obvious, reordering automatic, and production easier.
 Use AI where it reduces ambiguity, not where it creates more review work.
 Treat brand as a business system, not a decoration layer.
 Prioritize the few actions that move metrics; park or kill the rest.
 Design tools and processes that make teams calmer, faster, and more consistent.
Amanda Pharis | Leadership Portfolio | Selected examples generalized for confidentiality
AMANDA PHARIS
Brand, Growth Systems & AI Innovation
I am strongest in environments where the business problem is cross-functional: a brand needs
sharper positioning, marketing needs to become a system, AI needs practical implementation, and
operations need fewer heroic cleanup weeks.
Vancouver, WA | Open to remote and relocation | pharis.amanda@gmail.com | pharis.design
Selected examples generalized for confidentiality. Deeper project detail, screenshots, and implementation artifacts
available for discussion during interviews.